<template>
    <div>
      <h2>{{ pokemonDetails.name }}</h2>
    </div>
  </template>
  
  <script>
  import axios from 'axios';
  
  export default {
    name: 'DetailsPokemon',
    data() {
      return {
        pokemonDetails: null
      };
    },
    props: {
      id: {
        type: Number,
        required: true
      }
    },
    async created() {
      try {
        const response = await axios.get(`https://pokebuildapi.fr/api/v1/pokemon/${this.id}`);
        this.pokemonDetails = response.data;
      } catch (error) {
        console.error('Erreur lors de la récupération des détails du Pokémon:', error);
      }
    }
  };
  </script>
  
  