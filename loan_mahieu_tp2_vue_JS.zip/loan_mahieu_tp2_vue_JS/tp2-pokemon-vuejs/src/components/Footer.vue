<template>
  <footer class="footer">
    <p>MAHIEU Loan TP-B</p>
  </footer>
</template>

<script>
export default {
  name: 'Footer'
};
</script>

<style scoped>
.footer {
  position: relative;
  left: 0;
  bottom: 0;
  width: 100%;
  background-color: #222;
  color: white;
  text-align: center;
  padding: 0.5rem 0; 
}</style>