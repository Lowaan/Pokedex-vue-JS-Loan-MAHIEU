<template>
  <div class="pokedex">
    <PokemonCard
      v-for="pokemon in pokemons"
      :key="pokemon.name"
      :pokemon="pokemon"
    />
  </div>
</template>

<script>
import PokemonCard from './PokemonCard.vue';

export default {
  data() {
    return {
      selectedGeneration: '1'
    };
  },
  methods: {
    fetchPokemonsByGeneration() {
    },
  },
  name: 'Pokedex',
  props: {
    pokemons: Array
  },
  components: {
    PokemonCard
  }
};
  
</script>
  <style scoped>
  .pokedex {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
  }
  </style>
  