// router/index.js
import Vue from 'vue';
import VueRouter from 'vue-router';
import DetailsPokemon from '../components/DetailsPokemon.vue';

Vue.use(VueRouter);

const routes = [
  {
    path: '/pokemon/:id',
    name: 'DetailsPokemon',
    component: DetailsPokemon,
    props: true
  },
];

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
});

export default router;
